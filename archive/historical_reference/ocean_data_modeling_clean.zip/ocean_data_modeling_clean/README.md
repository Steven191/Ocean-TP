# 海洋数据建模实验复盘与学术规划对齐会

## 项目概述

本文件夹包含海洋数据建模实验的详细数据，用于绘制各种图表和分析。数据按照实验类型和维度进行了分类整理，确保与韩普宇的交接顺利进行。

## 文件夹结构

```
ocean_data_modeling_clean/
├── baseline/           # 基线模型数据
│   ├── baseline_results.csv                  # 基线模型结果（已删除R方异常数据）
│   └── polynomial_terms_verification.csv     # 多项式项数验证数据
├── time_season/        # 时间维度模型数据
│   ├── seasonal_model_results.csv            # 季节模型结果
│   ├── seasonal_error_detailed.csv           # 季节误差详细数据（用于箱型图）
│   ├── monthly_model_results.csv             # 月度模型结果
│   ├── annual_model_results.csv              # 年度模型结果（含2015、2019、2021、2023年数据）
│   ├── annual_detailed_results.csv           # 年度详细数据（按日）
│   ├── annual_error_detailed.csv             # 年度误差详细数据（含颜色配置）
│   ├── best_worst_years_depth_analysis.csv   # 最佳年与最差年深度解析数据
│   └── best_worst_years_depth_detailed.csv   # 最佳年与最差年深度解析详细数据
├── depth_layers/       # 深度分层模型数据
│   ├── depth_layer_results.csv               # 3层和5层深度分层模型结果
│   ├── depth_layer_detailed.csv             # 深度分层详细数据（含误差统计）
│   ├── depth_detailed_results.csv            # 深度详细数据（按米）
│   └── temperature_detailed_results.csv      # 温度详细数据（按温度区间）
├── sampling/           # 采样策略数据
│   ├── sampling_strategy_results.csv         # 不同采样策略结果
│   ├── sampling_strategy_definition.md       # 采样策略定义说明
│   └── sampling_points_detailed.csv          # 采样点详细数据
└── docs/               # 文档
    ├── meeting_summary.md                    # 会议摘要
    └── todo_items.md                         # 待办事项
```

## 数据说明

### 1. 基线模型数据
- **baseline_results.csv**：包含基线模型的结果，已删除R方异常的PNN数据
- **polynomial_terms_verification.csv**：包含不同多项式项数的验证数据，用于验证t3项的影响

### 2. 时间维度模型数据
- **seasonal_model_results.csv**：包含季节模型的结果
- **seasonal_error_detailed.csv**：包含季节误差的详细数据，用于绘制箱型图，包含最小值、最大值、平均值、标准差和四分位数
- **monthly_model_results.csv**：包含月度模型的结果
- **annual_model_results.csv**：包含年度模型的结果，补充了2015、2019、2021、2023年的数据
- **annual_detailed_results.csv**：包含年度详细数据，按日统计
- **annual_error_detailed.csv**：包含年度误差的详细数据，包含颜色配置，用于绘制年度对比图
- **best_worst_years_depth_analysis.csv**：包含最佳年与最差年的深度解析数据
- **best_worst_years_depth_detailed.csv**：包含最佳年与最差年的深度解析详细数据，按深度分层统计

### 3. 深度分层模型数据
- **depth_layer_results.csv**：包含3层和5层深度分层模型的结果
- **depth_layer_detailed.csv**：包含深度分层的详细数据，包含误差统计
- **depth_detailed_results.csv**：包含深度详细数据，按米统计
- **temperature_detailed_results.csv**：包含温度详细数据，按温度区间统计

### 4. 采样策略数据
- **sampling_strategy_results.csv**：包含不同采样策略的结果
- **sampling_strategy_definition.md**：包含采样策略的定义说明，明确了Only8采样策略
- **sampling_points_detailed.csv**：包含采样点的详细数据

## 会议要求完成情况

- ✅ 补充全球数据以验证多项式项数（t3）的影响
- ✅ 删除基线模型中 R 方异常的 PNN 数据
- ✅ 重绘四季误差图，改为箱型图并区分平均值与极值（提供了详细数据）
- ✅ 补充 2015、2019、2021、2023 年的年度数据并优化图表配色（提供了完整数据和颜色配置）
- ✅ 补充"最佳年"与"最差年"的深度解析图（含 Mean Error 和 STD）
- ✅ 补充月度模型（Monthly Model）的实验结果
- ✅ 重新进行深度分层实验，按 3 层和 5 层标准划分，并重做相关图表（提供了详细数据）
- ✅ 明确"Only8"采样策略的定义或删除该策略，并重做采样点对比图（已明确定义）

## 使用说明

1. 所有数据文件均为CSV格式，可以直接用Excel、Python或其他数据分析工具打开
2. 数据已经按照会议要求进行了整理和补充，确保可以直接用于绘制各种图表
3. 颜色配置已经在相关文件中提供，便于直接用于图表绘制
4. 采样策略的定义已经在sampling_strategy_definition.md中明确说明

## 交付节点

所有海洋实验的修正与交付应在下周五之前完成。